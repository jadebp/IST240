import java.awt.*;
import javax.swing.*;

public class Game2 extends JPanel {

    

    public Game2() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}