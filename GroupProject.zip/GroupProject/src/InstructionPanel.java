import java.awt.*;
import javax.swing.*;

public class InstructionPanel extends JPanel {

    

    public InstructionPanel() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}