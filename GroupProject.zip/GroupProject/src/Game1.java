import java.awt.*;
import javax.swing.*;

public class Game1 extends JPanel {

    

    public Game1() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}