import java.awt.*;
import javax.swing.*;

public class OptionPanel extends JPanel {

    

    public OptionPanel() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}