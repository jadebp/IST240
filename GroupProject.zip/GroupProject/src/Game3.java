import java.awt.*;
import javax.swing.*;

public class Game3 extends JPanel {

    

    public Game3() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}