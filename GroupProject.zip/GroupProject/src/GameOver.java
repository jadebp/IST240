import java.awt.*;
import javax.swing.*;

public class GameOver extends JPanel {

    

    public GameOver() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}