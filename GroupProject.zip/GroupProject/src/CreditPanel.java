import java.awt.*;
import javax.swing.*;

public class CreditPanel extends JPanel {

    

    public CreditPanel() {
        super();
        BorderLayout border = new BorderLayout();
        setLayout(border);
        setBackground(Color.gray);

        
    }

}